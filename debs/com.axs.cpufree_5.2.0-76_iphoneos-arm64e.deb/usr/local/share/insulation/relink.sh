#!/bin/sh
# 只做一件事：保证「停充守护读的那个文件名」永远指向「设置面板真正写的那份配置」。
# 绝不写任何配置内容、绝不删配置、绝不重建默认值 —— 面板那份是唯一真身。
#
# 调度：开机（RunAtLoad）+ 每 10 分钟检查一次。以前是每 30 秒跑一次，
# 一天要拉起将近 3000 次 /bin/sh，白白唤醒 CPU，对后台待机没有意义，
# 真正需要的时机只有「重启 / 换容器 / 设置面板重写配置」，所以频率降到 10 分钟。
# 每次检查只做 readlink 比对，软链已经正确就直接退出，不做任何写操作。

INS_NAME=com.be-huge.insulation-prefs.plist
HU_NAME=com.huayuarc.cputhermal.plist

for d in /var/mobile/Library/Preferences \
         /var/jb/var/mobile/Library/Preferences \
         /var/mobile/Containers/Shared/AppGroup/.jbroot-*/var/mobile/Library/Preferences; do
  [ -d "$d" ] || continue
  ins="$d/$INS_NAME"
  hu="$d/$HU_NAME"
  # 真身不在就什么都不做，绝不凭空造文件
  [ -f "$ins" ] || continue
  if [ -L "$hu" ] && [ "$(readlink "$hu" 2>/dev/null)" = "$ins" ]; then
    continue
  fi
  rm -f "$hu" 2>/dev/null || true
  ln -s "$ins" "$hu" 2>/dev/null || true
  # 只在真的重建软链时改一次属主，避免每次唤醒都去碰文件元数据
  chown -h mobile:mobile "$hu" 2>/dev/null || true
done
exit 0
