# URL Scheme Guard Core

Rule-driven URL scheme interception. The rules live in one property list, the
package includes a Settings pane, and a Darwin notification tells every
injected process to reload.

## Files

| Path | Role |
| --- | --- |
| `<jbroot>/var/mobile/Library/Preferences/com.doimty.urlschemeguard.plist` | the rules. Absent by default, and absent means inert. |
| `<jbroot>/var/mobile/Library/Preferences/com.doimty.urlschemeguard.verbose` | optional marker. Its presence forces diagnostic logging on even if the rules file cannot be read. |
| `<jbroot>/Library/URLSchemeGuard/com.doimty.urlschemeguard.sample.plist` | copyable example. Never read by the tweak. |
| `<jbroot>/Library/MobileSubstrate/DynamicLibraries/URLSchemeGuard.dylib` | the tweak, injected into processes that load UIKit. |
| `<jbroot>/Library/MobileSubstrate/DynamicLibraries/URLSchemeGuardLSD.dylib` | the same rules, enforced inside `lsd`. |

`<jbroot>` is your bootstrap's root. On RootHide that is the jailbreak root, on
rootless it is `/var/jb`, on rootful it is `/`. The tweak resolves this through
libroothide's `jbroot()`, so there is no path for you to configure.

## Two enforcement layers

The UIKit layer only sees a URL when the app that wants to open it was itself
injected and called `UIApplication` or `LSApplicationWorkspace` directly. That
misses anything routed through a broker or issued by a process the injector
skips, which is why blocking could look like it did nothing.

Every open ultimately reaches the Launch Services daemon over XPC, so the second
layer hooks `lsd` itself and sees every request regardless of its origin. The
caller is identified from the XPC connection's pid, resolved through
`proc_pidpath` to a bundle id; nothing the requesting process claims about
itself is trusted.

The daemon layer refuses only. A `Block` rule refuses, and so does a `Redirect`
rule, because "never open the original URL" is what the rule asks for and a
daemon cannot rewrite the URL safely. The full redirect, where the replacement
URL is actually opened, still happens in the app process. So a redirect rule
behaves as a redirect for injected apps and as a block for everything else.

Installing restarts `lsd` so the interceptor loads; launchd brings it straight
back. Both layers fail open: on any unexpected input, a missing selector, or an
unreadable rules file, the original implementation runs.

## Settings and per-app rules

The root page has three things on it: the master switch, `Applications`, and
`Advanced rules`. Switches are the primary path; text editing lives one level
down because a text field is authoritative on save, so anything it cannot
represent gets removed. That is a fine contract for pasting a rule set and a bad
one to leave next to the master switch.

`Applications` is populated from installed LaunchServices records. Each row
summarises what the rules say about that app rather than repeating its bundle id,
which you already know from picking it by name. The two counts are labelled by
direction and deliberately not merged, because they run opposite ways:
`N of M inbound blocked` is about schemes that open this app, `N blocked for it`
is about schemes this app may not open.

An app's detail page blocks its registered schemes globally with one switch each.
The same page adds caller-scoped blocks for that app, stored as `OnlyBundles` on
the existing scheme entries; `Choose an app to block` is the switch-based path,
and `Advanced caller rules` is the same list as text, for a scheme this device
does not register and discovery therefore cannot offer.

These are different operations. A registered scheme belongs to the target app,
while `OnlyBundles` identifies the process that called the URL API. When iOS
routes an open through a broker such as SpringBoard, the broker is the caller
that the hook can identify.

The schema is unchanged. Global and hand-written entries are not silently
converted by the app editor. Removing the last caller from a scoped entry
deletes the entry rather than writing an empty `OnlyBundles`, because an empty
list means every caller. Both text editors preserve everything they cannot
show: scoped entries, exceptions, redirects they do not own, and malformed
entries stay byte-for-byte as you wrote them.

Clearing a text field means "remove every rule of this kind". Text that fails to
parse does not: if any line or token in the field cannot be read, the save is
refused, the message quotes what it could not use, and the file is left alone.
Both cases look identical to the code and not at all alike to you. These fields
replace the rules they show, so skipping one bad line would delete whatever rule
that line was meant to keep, and a partial success is what hides it. One earlier
version deleted two live rules because a space had been typed instead of a
newline.

## Activating rules

```sh
cp /Library/URLSchemeGuard/com.doimty.urlschemeguard.sample.plist \
   /var/mobile/Library/Preferences/com.doimty.urlschemeguard.plist
# edit it, set Enabled to true, then:
notify_post com.doimty.urlschemeguard.rules-changed
```

Paths above are as seen from a shell inside the bootstrap. A respring is needed
once after install so already-running apps get injected; after that, the
notification is enough.

## Rule contract

Root dictionary:

| Key | Type | Meaning |
| --- | --- | --- |
| `Enabled` | Boolean | Master switch. Absent, `false`, or any non-boolean means nothing is ever intercepted. |
| `DiagnosticLogging` | Boolean | Optional, default `false`. Production logging is off unless this is `true` or the verbose marker exists. |
| `Schemes` | Dictionary | Key is a URL scheme, matched case-insensitively. Value is an entry dictionary. |

Entry dictionary:

| Key | Type | Meaning |
| --- | --- | --- |
| `Blocked` | Boolean | **Required.** Must be a real `<true/>` or `<false/>`; `<integer>1</integer>` is rejected. `false` makes the entry inert. |
| `Redirect` | String | Optional. Either a bare scheme (`https`, `https:`) or an absolute URL (`https://example.com/x`). A bare scheme keeps the rest of the original URL; an absolute URL replaces it. Redirecting a scheme to itself is rejected. |
| `OnlyBundles` | Array of strings | Optional. When present and non-empty, the entry applies only to these caller bundle identifiers, matched case-insensitively. |
| `ExceptBundles` | Array of strings | Optional. These callers are never affected. Checked first, so it beats `OnlyBundles`. |

## Validation

Per entry the parser is strict and fails closed on that entry: a wrong type, an
invalid scheme key, an invalid or self-referential redirect, a duplicate scheme,
or a non-string element in a bundle list discards the whole entry. A discarded
entry contributes nothing, so that scheme keeps its original behavior.

Globally the parser fails open: a missing, oversized, unparseable, or
non-dictionary root produces an inert ruleset. A broken configuration file
cannot brick URL handling.

## What a match does

Blocked, no redirect:

| Entry point | Result |
| --- | --- |
| `-[UIApplication canOpenURL:]` | `NO` |
| `-[UIApplication openURL:options:completionHandler:]` | completion handler called with `NO`, original never called |
| legacy `-[UIApplication openURL:]` | `NO` |
| `LSApplicationWorkspace` `openURL:`, `openURL:withOptions:`, `openSensitiveURL:withOptions:` | `NO` |
| `applicationsAvailableForOpeningURL:` | empty array |
| `applicationsAvailableForHandlingURLScheme:` | empty array |

Blocked with a valid redirect: the openers call the original with the rewritten
URL. `canOpenURL:` answers `YES`, because the redirect target is what will
handle it and answering `NO` would stop most callers from ever calling
`openURL:`, silently disabling the redirect. The availability list queries are
left alone.

If the redirect target is itself blocked for the same caller, the result
degrades to a plain block. Nothing is opened. There is no multi-hop chasing, so
a rule set cannot loop.

## Diagnostics

Off by default. Turn it on with `DiagnosticLogging`, or with the marker file
when the rules file itself is the suspect:

```sh
touch /var/mobile/Library/Preferences/com.doimty.urlschemeguard.verbose
notify_post com.doimty.urlschemeguard.rules-changed
```

Lines are tagged `[URLSchemeGuard]` in the system log. Remove the marker when
finished: every injected process logs, so this is noisy.
